from pathlib import Path
import json,hashlib
from PIL import Image
ROOT=Path(__file__).parent
# Logo changes are produced by the image editor. This step only encodes its
# completed PNG files as JPEGs for portable catalogue delivery; it does no drawing.
ps=json.loads((ROOT/'products.json').read_text())
ids=['003-07','004-02','004-03','004-04','004-05','004-06','004-07','005-06','006-07','006-08','009-07','009-08']
log=[]
for p in ps:
 for j,im in enumerate(p['images'],1):
  ident=f'{p["catalogue_code"][-3:]}-{j:02}'
  im['source_sha256']=im.get('source_sha256',im['sha256'])
  im['source_dimensions']=[im['downloaded_width'],im['downloaded_height']]
  im['branding_edit']='None'
  if ident in ids:
   edited=ROOT/'edits'/f'{ident}.png';assert edited.exists()
   with Image.open(edited) as image:
    assert image.mode in ['RGB','RGBA']
    im['downloaded_width'],im['downloaded_height']=image.size
    image.convert('RGB').save(ROOT/im['local_path'],format='JPEG',quality=95,subsampling=0,optimize=True)
   im['branding_edit']='Leather Gear marks replaced with FBG Sports using image editing'
  b=(ROOT/im['local_path']).read_bytes();im['sha256']=hashlib.sha256(b).hexdigest();im['bytes']=len(b)
  if ident in ids:log.append({'reference':p['catalogue_code'],'sequence':j,'delivered_path':im['local_path'],'source_url':im['src'],'source_sha256':im['source_sha256'],'delivered_sha256':im['sha256'],'edit':im['branding_edit'],'editor_output':f'edits/{ident}.png'})
assert len(log)==12
(ROOT/'products.json').write_text(json.dumps(ps,indent=2,ensure_ascii=False))
(ROOT/'watermark-change-log.json').write_text(json.dumps(log,indent=2))
print('Prepared',len(log),'FBG-branded photographs. All other product photos untouched.')
