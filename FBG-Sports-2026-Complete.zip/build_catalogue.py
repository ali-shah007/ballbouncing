from pathlib import Path
import json,csv,math,html,zipfile,hashlib
from collections import Counter
from reportlab.pdfgen import canvas
from reportlab.lib.colors import HexColor, Color, white
from reportlab.lib.pagesizes import A4
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from reportlab.platypus import Paragraph,Table,TableStyle
from reportlab.lib.styles import ParagraphStyle
from reportlab.lib.utils import ImageReader
from PIL import Image
from openpyxl import Workbook
from openpyxl.styles import Font,PatternFill,Alignment
from editorial import SPECS,SIZE_ROWS
ROOT=Path(__file__).parent
OUT=ROOT/'deliverables';OUT.mkdir(exist_ok=True)
ps=json.loads((ROOT/'products.json').read_text())
for p,s in zip(ps,SPECS):p['editorial']=s;p['boot_images']=p['images'][:-1]
DATE='1 November 2026'
W,H=A4;M=36;CW=W-2*M
INK=HexColor('#F4F6FA');MUTED=HexColor('#B2BDCA');PAPER=HexColor('#111B26');ACC=HexColor('#FF3741');LINE=HexColor('#3D4B5C');PALE=HexColor('#253546')
for name,file in [('Sans','DejaVuSans.ttf'),('Bold','DejaVuSansCondensed-Bold.ttf'),('Light','DejaVuSans-ExtraLight.ttf'),('Italic','DejaVuSans-Oblique.ttf')]:pdfmetrics.registerFont(TTFont(name,'/usr/share/fonts/truetype/dejavu/'+file))
pdfmetrics.registerFontFamily('Sans',normal='Sans',bold='Bold',italic='Italic',boldItalic='Bold')
c=canvas.Canvas(str(OUT/'FBG-Sports-2026-Leather-Boots-Catalogue.pdf'),pagesize=A4,pageCompression=1)
c.setTitle('FBG Sports 2026 | Leather Boots Catalogue');c.setAuthor('FBG Sports');c.setSubject('11 leather boot models; complete photography, specifications and sizing guide')
page_no=0

def rect(x,y,w,h,color,stroke=None):
 c.setFillColor(color);c.setStrokeColor(stroke or color);c.rect(x,H-y-h,w,h,fill=1,stroke=bool(stroke))
def line(x,y,x2,y2,col=LINE,width=.6):
 c.setStrokeColor(col);c.setLineWidth(width);c.line(x,H-y,x2,H-y2)
def txt(x,y,s,size=10,font='Sans',color=INK):
 if font=='Bold' and size>=22:s=str(s).upper()
 c.setFillColor(color);c.setFont(font,size);c.drawString(x,H-y-size*.82,str(s))
def right(x,y,s,size=10,font='Sans',color=INK):
 c.setFillColor(color);c.setFont(font,size);c.drawRightString(x,H-y-size*.82,str(s))
def para(x,y,s,w,size=10,leading=None,font='Sans',color=INK,maxh=None):
 style=ParagraphStyle('t',fontName=font,fontSize=size,leading=leading or size*1.5,textColor=color,spaceAfter=0)
 p=Paragraph(s,style);_,hh=p.wrap(w,2000)
 if maxh is not None:assert hh<=maxh+.1,(s[:80],hh,maxh,page_no)
 p.drawOn(c,x,H-y-hh);return hh

def label(x,y,s,color=ACC):txt(x,y,s.upper(),8,'Bold',color)
def picture(im,x,y,w,h,bg=white,pad=8):
 rect(x,y,w,h,bg)
 path=ROOT/im['local_path']
 iw,ih=im['downloaded_width'],im['downloaded_height'];scale=min((w-2*pad)/iw,(h-2*pad)/ih)
 dw,dh=iw*scale,ih*scale
 c.drawImage(str(path),x+(w-dw)/2,H-y-(h+dh)/2,width=dw,height=dh,preserveAspectRatio=True,mask='auto')
 # Red technical corner marks frame the untouched product photography.
 line(x,y+h,x+15,y+h,ACC,1.8);line(x,y+h,x,y+h-15,ACC,1.8)
 line(x+w-15,y,x+w,y,ACC,1.8);line(x+w,y,x+w,y+15,ACC,1.8)
def polygon(points,color):
 c.setFillColor(color);p=c.beginPath();p.moveTo(points[0][0],H-points[0][1])
 for x,y in points[1:]:p.lineTo(x,H-y)
 p.close();c.drawPath(p,fill=1,stroke=0)
def brand_logo(x,y,w):
 # Place the generated cover within a clipped viewport; keep the source artwork intact.
 cover=ROOT/'assets/FBG-Sports-2026-Cover.png'
 scale=w/335;h=139*scale
 c.saveState();p=c.beginPath();p.rect(x,H-y-h,w,h);c.clipPath(p,stroke=0,fill=0)
 c.drawImage(str(cover),x-72*scale,H-(y-53*scale)-1493*scale,width=1054*scale,height=1493*scale,mask='auto')
 c.restoreState()
def start(section,bookmark=None):
 global page_no
 page_no+=1;rect(0,0,W,H,PAPER)
 if bookmark:c.bookmarkPage(bookmark);c.addOutlineEntry(section,bookmark,level=0,closed=False)
 # Racing-red diagonals and a dark masthead carry the supplied FBG direction.
 rect(0,0,W,57,HexColor('#0C1520'));brand_logo(M,12,72)
 right(W-M,27,'LEATHER BOOTS  /  2026',8,'Bold',INK)
 polygon([(W-154,51),(W-39,51),(W-34,57),(W-159,57)],ACC)
 line(M,57,W-M,57,LINE,.5)
 rect(0,72,4,113,ACC)
 label(M,76,section)
 # Subtle technical line pattern in the bottom corner, away from content.
 for q in range(4):line(W-90+q*13,H-64,W-78+q*13,H-79,LINE,.5)
def end():
 line(M,H-43,W-M,H-43,LINE,.6)
 polygon([(M,H-43),(M+91,H-43),(M+85,H-38),(M,H-38)],ACC)
 txt(M,H-26,'FBG SPORTS  /  2026 COLLECTION',7,'Bold',MUTED)
 right(W-M,H-29,f'{page_no:02}',10,'Bold',ACC);c.showPage()
def link(url,x,y,w,h):c.linkURL(url,(x,H-y-h,x+w,H-y),relative=0,thickness=0)
def page_link(dest,x,y,w,h):c.linkRect('',dest,(x,H-y-h,x+w,H-y),relative=0,thickness=0)

# 01 / Full-bleed cinematic cover, generated from the user's art direction.
page_no=1
c.drawImage(str(ROOT/'assets/FBG-Sports-2026-Cover.png'),0,0,width=W,height=H,mask='auto')
# Searchable invisible metadata; the cover's visible typography is in the artwork.
t=c.beginText(34,H-80);t.setFont('Bold',18);t.setTextRenderMode(3);t.textLine('FBG SPORTS 2026 LEATHER BOOTS CATALOGUE');c.drawText(t)
c.bookmarkPage('cover');c.addOutlineEntry('Cover','cover',0);c.showPage()

# 02 / Guide
start('The collection', 'guide');txt(M,106,'Find your silhouette.',30,'Bold')
para(M,155,'From compact lace-ups to tall patrol profiles, this catalogue brings the complete leather-boot range into one visual reference.',CW,11,17)
for x,n,b in [(M,'11','MODELS'),(M+180,'72','BOOT PHOTOS'),(M+350,'15','NUMERIC US SIZES')]:
 txt(x,217,n,39,'Light',ACC);label(x,267,b,MUTED)
line(M,303,W-M,303)
sections=[('01','Harness & engineer','Ring hardware, buckle straps and pull-on profiles. Compare 11-inch and 16-inch options.','FBG-LB-001 to 004'),('02','Lace-up profiles','Ankle, mid-calf and tall designs with ten-hole, twenty-eye and semi lace-to-toe configurations.','FBG-LB-005 to 008 + 010'),('03','Patrol silhouettes','Clean tall shafts, low block heels and a choice of pull-on or closed-lacing details.','FBG-LB-009 + 011')]
y=325
for no,title,body,refs in sections:
 txt(M,y,no,22,'Light',ACC);txt(M+49,y,title,15,'Bold')
 para(M+49,y+30,body,CW-49,10,15);label(M+49,y+72,refs,MUTED);line(M,y+102,W-M,y+102);y+=122
label(M,718,'Using this catalogue')
para(M,741,'FBG-LB codes are catalogue references. Specifications and imagery are compiled from My Leather Gear. Prices are on request; source retail prices are supplied separately.',CW,8.3,12.5)
end()

# 03–04 / Visual index
for chunk,startidx in [(ps[:6],0),(ps[6:],6)]:
 start('Range index', 'range' if not startidx else 'range-2')
 txt(M,106,'The complete line-up.',28,'Bold');para(M,147,'Select a reference to jump to its product specification.',CW,9.5,color=MUTED)
 gap=14;cw=(CW-2*gap)/3;top=187;ch=278
 for j,p in enumerate(chunk):
  col=j%3;row=j//3;x=M+col*(cw+gap);y=top+row*(ch+16);s=p['editorial']
  picture(p['boot_images'][0],x,y,cw,183,pad=8)
  label(x,y+195,p['catalogue_code']);para(x,y+214,s['name'],cw,11.2,15,font='Bold',maxh=32)
  para(x,y+247,s['short_height']+'  /  '+s['category'].split(' / ')[0],cw,8.2,12,color=MUTED)
  page_link(p['catalogue_code'],x,y,cw,ch)
  p['pdf_spec_page']=6+2*(startidx+j);p['pdf_gallery_page']=7+2*(startidx+j)
 if len(chunk)==5:
  x=M+2*(cw+gap);y=top+ch+16;rect(x,y,cw,183,HexColor('#253546'))
  label(x+13,y+17,'All models',white);txt(x+13,y+53,'BLACK',22,'Bold',white)
  para(x+13,y+91,'Leather uppers<br/>D / medium + EE / extra-wide<br/>Custom option listed',cw-26,9,17,color=white)
 end()

# 05 / Comparison
start('Range comparison','compare');txt(M,106,'Compare at a glance.',28,'Bold')
para(M,151,'Heights are reproduced as listed. Measurement methods vary by model; the Street Stride value is overall height, not shaft height.',CW,9.5,14)
headers=['REF.','MODEL','HEIGHT','ENTRY / CLOSURE','OUTSOLE']
rows=[]
for p in ps:
 s=p['editorial'];out='Dress / low block' if p['catalogue_code']=='FBG-LB-009' else 'Rubber / low block' if p['catalogue_code']=='FBG-LB-011' else 'Rubber lug' if p['catalogue_code']=='FBG-LB-005' else 'Lug / commando' if p['catalogue_code']=='FBG-LB-010' else 'Lug'
 closure={'001':'Pull-on harness','002':'Pull-on / buckles','003':'Pull-on / buckles','004':'Pull-on harness','005':'10-hole lace-up','006':'Laces + side zip','007':'Laces / hooks','008':'Lace-to-toe / hooks','009':'Pull-on / buckle','010':'20-eye lace-up','011':'Closed laces / buckle'}[p['catalogue_code'][-3:]]
 rows.append([p['catalogue_code'][-3:],s['name'],s['short_height'],closure,out])
stylesmall=ParagraphStyle('cell',fontName='Sans',fontSize=8,leading=12,textColor=INK)
data=[[Paragraph('<b>'+x+'</b>',stylesmall) for x in headers]]+[[Paragraph(html.escape(str(x)),stylesmall) for x in r] for r in rows]
t=Table(data,colWidths=[31,135,77,160,120],rowHeights=[30]+[37]*11)
t.setStyle(TableStyle([('BACKGROUND',(0,0),(-1,0),PALE),('ROWBACKGROUNDS',(0,1),(-1,-1),[HexColor('#1C2A39'),PAPER]),('VALIGN',(0,0),(-1,-1),'MIDDLE'),('LEFTPADDING',(0,0),(-1,-1),7),('RIGHTPADDING',(0,0),(-1,-1),6),('LINEBELOW',(0,0),(-1,0),.8,INK),('LINEBELOW',(0,1),(-1,-1),.4,LINE)]))
t.wrap(CW,1000);t.drawOn(c,M,H-211-437)
label(M,680,'Shared options')
para(M,702,'Black · US sizes 6.5–12 in listed half sizes, then 13, 14 and 15 · Custom option · D / Regular / Medium and EE / X-Wide.',CW,10,16)
para(M,752,'Outsole branding and resistance claims are source-listed. No independent test certificates are supplied. The 20-Hole Dominator is described as steel-toe; no safety rating is stated.',CW,8,12,color=MUTED)
end()

# 06–27 / Each model
for idx,p in enumerate(ps):
 s=p['editorial'];code=p['catalogue_code'];start(s['category'],code)
 txt(M,105,s['name'],30 if len(s['name'])<22 else 27,'Bold')
 label(M,151,code);right(W-M,151,'BLACK  /  PRICE ON REQUEST',8,'Bold',ACC)
 para(M,180,s['intro'],CW,10.2,15.5,maxh=47)
 # Two aligned columns: large lead photo and technical stack.
 ix=M;iy=250;iw=246;ih=394
 picture(p['boot_images'][0],ix,iy,iw,ih,pad=14)
 label(ix,iy+407,'01 / '+s['captions'][0],MUTED)
 sx=M+265;sw=CW-265;sy=250
 fields=[('UPPER',s['material']),('HEIGHT',s['height']),('CLOSURE',s['closure']),('TOE',s['toe']),('OUTSOLE',s['sole']),('LINING',s['lining']),('HARDWARE',s['hardware'])]
 for k,v in fields:
  label(sx,sy,k,MUTED);hh=para(sx,sy+15,html.escape(v),sw,9.3,13.3,maxh=41);sy+=hh+29
 assert sy<694,(code,sy)
 # Long galleries get one additional image here, with the rest on the facing page.
 extra=len(p['boot_images'])>7
 if extra:
  picture(p['boot_images'][-1],M,681,83,87,pad=3)
  para(M+97,684,f'<b>{len(p["boot_images"]):02} / {s["captions"][-1]}</b><br/>Additional source view. The remaining photographs appear on the following gallery page.',141,8,12)
 else:
  label(M,685,'Design details')
  for j,f in enumerate(s['features']):para(M,707+j*20,'— '+html.escape(f),246,8.5,12,maxh=24)
 label(sx,703,'Fit & availability')
 state='Sold out at source; confirm availability.' if not any(v['available'] for v in p['variants']) else 'Source variants listed available; confirm order.'
 para(sx,723,'US 6.5–12 (listed half sizes), 13, 14, 15 + Custom.<br/>D / Medium or EE / X-Wide.<br/>'+state,sw,8.2,12,maxh=60)
 end()
 # Photo gallery; every source boot image appears once in product pages.
 start('Photo gallery',code+'-gallery');txt(M,106,s['name'],27,'Bold');label(M,149,code+' / additional views')
 rest=list(enumerate(p['boot_images'][1:-1] if extra else p['boot_images'][1:],2))
 gh=173;gap=17;gw=(CW-gap)/2;y0=185
 for j,(num,im) in enumerate(rest):
  x=M+(j%2)*(gw+gap);y=y0+(j//2)*198
  picture(im,x,y,gw,gh,pad=8)
  txt(x,y+182,f'{num:02} / {s["captions"][num-1]}',8,'Sans',MUTED)
 # Fill spare gallery cell with useful detail rather than duplicating photography.
 if len(rest)==5:
  x=M+gw+gap;y=y0+2*198;rect(x,y,gw,gh,PALE);label(x+16,y+16,'Design notes')
  yy=y+45
  for f in s['features']:
   hh=para(x+16,yy,html.escape(f),gw-32,9,13);yy+=hh+10
  assert yy<y+gh+1,(code,yy,y+gh)
 para(M,784,'Selected source images edited with FBG Sports watermarks. Colour and finish may vary between views.',CW,7.2,10,color=MUTED)
 end()

# 28 / Original sizing chart
start('Size & fit','sizing');txt(M,106,'Choose by measurement.',28,'Bold')
para(M,150,'All models list the same US-size options and two widths: D / Regular / Medium and EE / X-Wide. The source size chart is reproduced below without alteration.',CW,10,15)
chart=ps[0]['images'][-1];picture(chart,M,210,CW,484,pad=0)
label(M,716,'Before ordering')
para(M,737,'Confirm both feet, preferred socks, width and calf / shaft fit. The source chart repeats UK/AUS size 7 for US 7.5 and 8; confirm the mapping rather than assuming a universal conversion.',CW,9,13)
para(M,778,'Original chart supplied by My Leather Gear. Custom sizing is listed as a separate order option.',CW,7.4,11,color=MUTED)
end()

# 29 / Ordering
start('Ordering & custom options','ordering');txt(M,106,'Build the right enquiry.',28,'Bold')
para(M,153,'Use the catalogue reference and the checklist below when requesting a quotation. FBG Sports pricing, delivery and order terms should be confirmed separately.',CW,10.5,16)
blocks=[('01','Select your model','Quote the FBG-LB reference, model name and quantity. All source listings show black as the standard colour.'),('02','Specify the fit','Choose a listed US size or Custom, then D / Medium or EE / X-Wide. For a custom fit, include foot length, width and any requested calf / shaft measurements.'),('03','Describe custom changes','The source offers requests for leather colour, lining, unlisted sizes and extended shaft heights. Feasibility, surcharges and specifications require confirmation.'),('04','Confirm timing and finish','Source processing guidance is 7–9 business days for standard articles and up to two weeks for custom orders. This is not an FBG delivery commitment; transit time is additional.')]
y=221
for n,title,body in blocks:
 txt(M,y,n,22,'Light',ACC);txt(M+47,y+1,title,13,'Bold');para(M+47,y+28,body,CW-47,9.3,14)
 line(M,y+96,W-M,y+96);y+=116
rect(M,703,CW,77,HexColor('#253546'));label(M+15,716,'General leather care',white)
para(M+15,737,'Brush off dust; wipe with a soft cloth. Test care products on a hidden area. Dry away from direct heat and choose polish or conditioner suitable for the leather finish.',CW-30,9,13,color=white)
end()

# 30 / Provenance & source index
start('Source directory','sources');txt(M,106,'Every model, traceable.',27,'Bold')
para(M,150,'Product pages, original gallery files and variant data were retrieved from the collection below. Click a model title to open its source product page.',CW,9.8,15)
source='https://myleathergear.com/collections/leather-boots';txt(M,199,source,8.5,'Sans',ACC);link(source,M,194,CW,19)
y=235
for p in ps:
 label(M,y,p['catalogue_code']);h=para(M+86,y-2,html.escape(p['title']),CW-145,9.2,13,maxh=27)
 right(W-M,y,f'pp. {p["pdf_spec_page"]}–{p["pdf_gallery_page"]}',8.2,'Sans',MUTED)
 link(p['page_url'],M+82,y-4,CW-82,32);line(M,y+30,W-M,y+30);y+=43
label(M,728,'Edition notes')
para(M,749,'Compiled '+DATE+'. Source photography and specifications: My Leather Gear. Branding on 12 photos edited to FBG Sports. Cover: AI-generated campaign artwork. FBG-LB codes are editorial references; prices and contact details were not supplied.',CW,7.8,11.5)
end()
assert page_no==30,page_no
c.save()

# Reference workbook and flat data, including every variant and image source.
wb=Workbook();ws=wb.active;ws.title='Product reference'
heads=['Catalogue reference','Catalogue model','Source product name','Category','Source height','Upper','Colour','Closure','Toe','Outsole (source-listed)','Lining','Hardware','Source sizes','Source widths','Source availability','Source price min (USD)','Source price max (USD)','FBG price','Product URL','Spec page','Gallery page','Boot photo count','Source checked']
ws.append(heads)
for p in ps:
 s=p['editorial'];prices=[float(v['price']) for v in p['variants']]
 ws.append([p['catalogue_code'],s['name'],p['title'],s['category'],s['height'],s['material'],'Black',s['closure'],s['toe'],s['sole'],s['lining'],s['hardware'],', '.join(p['options'][0]['values']),', '.join(p['options'][1]['values']),'Available' if any(v['available'] for v in p['variants']) else 'Sold out',min(prices),max(prices),'Price on request',p['page_url'],p['pdf_spec_page'],p['pdf_gallery_page'],len(p['boot_images']),DATE])
vs=wb.create_sheet('All source variants');vs.append(['Catalogue reference','Source variant ID','Source SKU','US size','Width','Available at source','Source retail USD','Source compare-at USD','Grams (source field)'])
for p in ps:
 for v in p['variants']:vs.append([p['catalogue_code'],str(v['id']),v['sku'],v['option1'],v['option2'],v['available'],float(v['price']),float(v['compare_at_price']) if v['compare_at_price'] else None,v['grams']])
isheet=wb.create_sheet('Image manifest');isheet.append(['Catalogue reference','Image sequence','Type','Caption','Local path','Original URL','Width px','Height px','Delivered SHA256','Source SHA256','Branding edit'])
manifest=[]
for p in ps:
 for i,im in enumerate(p['images'],1):
  chart=i==len(p['images']);caption='Shared size chart' if chart else p['editorial']['captions'][i-1]
  row=[p['catalogue_code'],i,'Size chart' if chart else 'Boot photo',caption,im['local_path'],im['src'],im['downloaded_width'],im['downloaded_height'],im['sha256'],im.get('source_sha256',im['sha256']),im.get('branding_edit','None')]
  isheet.append(row);manifest.append(dict(zip(['reference','sequence','type','caption','local_path','source_url','width','height','sha256','source_sha256','branding_edit'],row)))
ss=wb.create_sheet('Source size chart');ss.append(['Foot length (in)','Foot length (cm)','USA','UK/AUS','EUR'])
for r in SIZE_ROWS:ss.append(r)
ns=wb.create_sheet('Read me')
for r in [
 ['FBG Sports 2026 — Leather Boots / Reference workbook'],['Compiled',DATE],['Scope','11 collection products; 352 size/width variants; 72 boot photos; shared size chart'],['Prices','USD prices are source-site retail observations, not FBG Sports quotations.'],['Stock','Source availability is a snapshot, not an FBG stock commitment.'],['Timing','Source processing: 7–9 business days standard; up to 2 weeks custom. Confirm FBG terms separately.'],['Specifications','Editorial summaries derived from source product descriptions; no independent tests or safety certificates supplied.'],['Identifiers','FBG-LB references are editorial. Original manufacturer/source SKUs are retained on the variant sheet.'],['Images','83 gallery entries comprise 72 boot photos and 11 copies of one shared size chart; 73 unique files by SHA256.'],['Sizes','Chart values transcribed as supplied; UK/AUS 7 is repeated for US 7.5 and US 8. Confirm measurements.'],['Credits','Source photography and specifications: My Leather Gear. Branding on 12 photos edited to FBG Sports using AI image editing. Cover is AI-generated campaign artwork.'],['Collection',source]]:ns.append(r)
for sh in wb:
 sh.freeze_panes='A2';sh.auto_filter.ref=sh.dimensions;sh.sheet_view.showGridLines=False
 for cell in sh[1]:cell.font=Font(bold=True,color='FFFFFF');cell.fill=PatternFill('solid',fgColor='111B26');cell.alignment=Alignment(wrap_text=True,vertical='center')
 sh.row_dimensions[1].height=30
 for col in sh.columns:
  vals=[str(x.value or '') for x in list(col)[:30]];width=min(70,max(16,max(len(v) for v in vals)*.72));sh.column_dimensions[col[0].column_letter].width=width
 for row in sh.iter_rows(min_row=2):
  for cell in row:
   cell.alignment=Alignment(vertical='top',wrap_text=True)
   if cell.row%2==0:cell.fill=PatternFill('solid',fgColor='F0F2F5')
   if isinstance(cell.value,str) and cell.value.startswith('https://'):cell.hyperlink=cell.value;cell.font=Font(color='D51F2A',underline='single')
ws.column_dimensions['O'].width=20
wb.save(OUT/'FBG-Sports-2026-Product-Reference.xlsx')
for name,sh in [('product-reference.csv',ws),('variant-reference.csv',vs),('image-manifest.csv',isheet),('size-chart.csv',ss)]:
 with (ROOT/name).open('w',newline='',encoding='utf-8-sig') as f:
  writer=csv.writer(f);writer.writerows(sh.values)
(ROOT/'image-manifest.json').write_text(json.dumps(manifest,indent=2))

# Portable editable HTML catalogue: no external dependencies or image hotlinks.
css='''*{box-sizing:border-box}html{scroll-behavior:smooth}body{margin:0;background:#111b26;color:#f4f6fa;font:16px/1.65 Arial,sans-serif}a{color:#ff4b53}header{background:#080e16;border-bottom:5px solid #ef1624}.cover{max-width:850px;margin:auto}.cover img{width:100%;height:auto;display:block}main,footer{max-width:1160px;margin:auto;padding:48px 28px}h2{font-size:clamp(28px,4vw,46px);line-height:1.1;letter-spacing:-.025em;text-transform:uppercase;border-left:5px solid #ef1624;padding-left:18px}h3{line-height:1.2}small,.muted{color:#b2bdca}.eyebrow{letter-spacing:.14em;text-transform:uppercase;font-size:12px;font-weight:bold;color:#ff4b53}.index{display:grid;grid-template-columns:repeat(3,1fr);gap:18px}.card{padding:16px;background:#1c2a39;border-bottom:3px solid #ef1624;display:block;text-decoration:none;color:inherit}.card img{width:100%;height:240px;object-fit:contain;background:white;padding:12px}.card .eyebrow{margin-top:17px}.card h3{font-size:21px;text-transform:uppercase}.product{border-top:1px solid #3d4b5c;margin-top:70px;padding-top:40px;break-before:page}.layout{display:grid;grid-template-columns:1fr 1fr;gap:30px}.lead{width:100%;height:550px;object-fit:contain;background:white;padding:16px;border-bottom:4px solid #ef1624}.details{display:grid;grid-template-columns:110px 1fr;gap:10px;font-size:14px}.details dt{font-weight:bold;color:#b2bdca;text-transform:uppercase}.details dd{margin:0}.gallery{display:grid;grid-template-columns:repeat(3,1fr);gap:18px;margin-top:24px}figure{margin:0;background:#1c2a39;padding:12px;border-bottom:2px solid #ef1624}figure img{width:100%;height:300px;object-fit:contain;background:white;padding:6px}figcaption{font-size:12px;color:#b2bdca;padding-top:8px}.sizes img{width:100%;max-width:720px;background:white}.scroll{overflow-x:auto}table{border-collapse:collapse;width:100%;font-size:13px}td,th{padding:12px;text-align:left;border-bottom:1px solid #3d4b5c}th{background:#253546}tbody tr:nth-child(odd){background:#1c2a39}footer{border-top:4px solid #ef1624;font-size:13px}footer b{font-size:24px;font-style:italic}@media(max-width:700px){.layout{grid-template-columns:1fr}.index,.gallery{grid-template-columns:repeat(2,1fr)}.card{padding:10px}.card img{height:180px}.card h3{font-size:17px}figure img{height:200px}.lead{height:400px}main,footer{padding:30px 18px}}@media print{body{-webkit-print-color-adjust:exact;print-color-adjust:exact}main,footer{max-width:none;padding:12mm}.index{grid-template-columns:repeat(3,1fr)}.gallery{grid-template-columns:repeat(3,1fr)}.gallery img{height:60mm}.lead{height:100mm}a{color:inherit}figure,.card{break-inside:avoid}.product{margin-top:0}header{break-after:page}.cover img{max-height:265mm;width:auto;max-width:100%;margin:auto}@page{size:A4;margin:10mm}}'''
e=html.escape
parts=['<!doctype html><html lang="en"><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1"><title>FBG Sports 2026 — Leather Boots</title><style>'+css+'</style><body>', '<header><div class="cover"><img src="assets/FBG-Sports-2026-Cover.png" alt="FBG Sports 2026 Leather Boots Catalogue — cinematic industrial campaign cover"></div></header><main><div class="eyebrow">FBG SPORTS / THE COMPLETE LEATHER COLLECTION</div><h2>The complete line-up</h2><div class="index">']
for p in ps:
 s=p['editorial'];parts.append(f'<a class="card" href="#{p["catalogue_code"]}"><img src="{p["boot_images"][0]["local_path"]}" alt="{e(s["name"])}"><div class="eyebrow">{p["catalogue_code"]}</div><h3>{e(s["name"])}</h3><small>{e(s["category"])} / {e(s["short_height"])}</small></a>')
parts.append('</div><h2>Compare the range</h2><div class="scroll"><table><thead><tr><th>Reference</th><th>Model</th><th>Height</th><th>Closure</th><th>Outsole</th></tr></thead><tbody>')
for p in ps:
 s=p['editorial'];parts.append('<tr>'+''.join('<td>'+e(x)+'</td>' for x in [p['catalogue_code'],s['name'],s['height'],s['closure'],s['sole']])+'</tr>')
parts.append('</tbody></table></div>')
for p in ps:
 s=p['editorial'];parts.append(f'<article class="product" id="{p["catalogue_code"]}"><div class="eyebrow">{p["catalogue_code"]} / {e(s["category"])}</div><h2>{e(s["name"])}</h2><p>{e(s["intro"])}</p><div class="layout"><img class="lead" src="{p["boot_images"][0]["local_path"]}" alt="{e(s["name"])}"><div><dl class="details">')
 for k,v in [('Upper',s['material']),('Colour','Black'),('Height',s['height']),('Closure',s['closure']),('Toe',s['toe']),('Outsole',s['sole']),('Lining',s['lining']),('Hardware',s['hardware']),('Sizes',', '.join(p['options'][0]['values'])),('Widths',', '.join(p['options'][1]['values']))]:parts.append(f'<dt>{k}</dt><dd>{e(v)}</dd>')
 parts.append('</dl><h3>Price on request</h3><ul>'+''.join('<li>'+e(f)+'</li>' for f in s['features'])+'</ul><p><small>Source availability: '+('Listed available' if any(v['available'] for v in p['variants']) else 'Sold out')+'. Confirm before ordering.</small></p></div></div><div class="gallery">')
 for j,im in enumerate(p['boot_images'][1:],1):parts.append(f'<figure><img src="{im["local_path"]}" alt="{e(s["captions"][j])}"><figcaption>{j+1:02} / {e(s["captions"][j])}</figcaption></figure>')
 parts.append(f'</div><p><small>Source: <a href="{p["page_url"]}">{e(p["title"])}</a></small></p></article>')
parts.append('<section class="product sizes"><h2>Size & fit</h2><p>Original source chart, reproduced without alteration. D / Medium and EE / X-Wide are listed for all models.</p><img src="'+ps[0]['images'][-1]['local_path']+'" alt="Original size chart from My Leather Gear"><p>Confirm foot length, width, socks and calf fit. The source repeats UK/AUS size 7 for US 7.5 and 8; confirm measurements before ordering.</p></section><section class="product"><h2>Ordering & custom options</h2>')
for n,t,b in blocks:parts.append('<h3>'+n+' / '+e(t)+'</h3><p>'+e(b)+'</p>')
parts.append('<h3>General leather care</h3><p>Brush off dust and wipe with a soft cloth. Test products on a hidden area. Dry away from direct heat; choose products suitable for the finish.</p></section></main><footer><b>FBG SPORTS / 2026</b><p>Compiled '+DATE+'. Product photography and source specifications: <a href="'+source+'">My Leather Gear</a>. Branding on 12 photos has been edited to FBG Sports. The cover is AI-generated campaign artwork. FBG-LB codes are editorial references, not manufacturer SKUs. Source claims are not independently certified. No FBG prices or contact details were supplied.</p></footer></body></html>')
(ROOT/'Catalogue.html').write_text(''.join(parts))
readme=f'''FBG SPORTS 2026 — LEATHER BOOTS / FBG WATERMARK EDITION
Compiled {DATE}

DELIVERY
The 30-page PDF retains all 11 models and all 72 boot views. Twelve photos originally carrying Leather Gear marks have been edited using the image editor to replace those marks with FBG Sports branding, including printed brand cards and corner badges. Sixty boot photos without those marks and the shared size chart are unchanged. The cinematic cover and charcoal/red theme are retained.

IMAGE FILES
The images/ folder contains 83 gallery entries: 72 boot photographs plus 11 identical copies of the shared chart (73 unique delivered files). All 12 edited images are encoded as high-quality JPEGs, without further resizing, for easy catalogue sharing. Master editor outputs are retained in the working workspace separately; no original Leather Gear-branded variants of the edited photos are included in the delivered image folder. The delivered manifest lists both original source SHA256 and delivered SHA256, plus branding edit status. watermark-change-log.json records the edited entries.

EDITABLE CATALOGUE
Open Catalogue.html with the images/ and assets/ folders beside it. build_catalogue.py and editorial.py rebuild the PDF and workbook with ReportLab, Pillow and openpyxl. The HTML is a responsive companion layout rather than the exact PDF layout.

REFERENCE DATA
Product-Reference.xlsx contains 11 product summaries, 352 source size/width variants, 83 image records and the source size chart. Source retail USD prices are historical observations, not FBG quotations. FBG prices remain Price on request. Stock and processing times describe the source listing when retrieved, not FBG commitments.

SOURCE AND EDITS
{source}
Source photography and specifications: My Leather Gear. FBG marks on the 12 affected photos were added digitally at the user's request; they do not verify physical boot branding or manufacturer identity. Image edits use AI and should be checked against actual goods when confirming orders. The cover is AI-generated campaign artwork inspired by the supplied FBG reference. FBG-LB codes are editorial references, not source/manufacturer SKUs. Original files remain preserved in the prior source archive, outside this delivery pack.

FIT
The source chart is reproduced as supplied and is not a universal size conversion. It repeats UK/AUS 7 for US 7.5 and 8; confirm measurements, width and calf fit before ordering.
'''
(ROOT/'README.txt').write_text(readme)
# Cover artwork is separate from the FBG-branded delivery image archive.
import shutil
shutil.copy2(ROOT/'assets/FBG-Sports-2026-Cover.png',OUT/'FBG-Sports-2026-Cover.png')
# Two portable archives: complete working pack and image-only source bundle.
with zipfile.ZipFile(OUT/'FBG-Sports-2026-Images.zip','w',zipfile.ZIP_DEFLATED) as z:
 for path in sorted((ROOT/'images').rglob('*')):
  if path.is_file():z.write(path,path.relative_to(ROOT))
 for name in ['image-manifest.csv','image-manifest.json','watermark-change-log.json','README.txt']:z.write(ROOT/name,name)
with zipfile.ZipFile(OUT/'FBG-Sports-2026-Complete-Catalogue-Pack.zip','w',zipfile.ZIP_DEFLATED) as z:
 for path in sorted(ROOT.rglob('*')):
  if path.is_file() and '__pycache__' not in path.parts and 'deliverables' not in path.parts and 'review' not in path.parts and 'edits' not in path.parts and not path.name.startswith('ocr-') and path.name!='contact-sheet.jpg':z.write(path,path.relative_to(ROOT))
 for name in ['FBG-Sports-2026-Leather-Boots-Catalogue.pdf','FBG-Sports-2026-Product-Reference.xlsx']:z.write(OUT/name,name)
print('BUILT',page_no,'pages;',sum(len(p['boot_images']) for p in ps),'boot photos;',sum(len(p['variants']) for p in ps),'variants')
for path in OUT.iterdir():print(path.name,path.stat().st_size)
