FBG SPORTS 2026 — LEATHER BOOTS / FBG WATERMARK EDITION
Compiled 1 November 2026

DELIVERY
The 30-page PDF retains all 11 models and all 72 boot views. Twelve photos originally carrying Leather Gear marks have been edited using the image editor to replace those marks with FBG Sports branding, including printed brand cards and corner badges. Sixty boot photos without those marks and the shared size chart are unchanged. The cinematic cover and charcoal/red theme are retained.

IMAGE FILES
The images/ folder contains 83 gallery entries: 72 boot photographs plus 11 identical copies of the shared chart (73 unique delivered files). All 12 edited images are encoded as high-quality JPEGs, without further resizing, for easy catalogue sharing. Master editor outputs are retained in the working workspace separately; no original Leather Gear-branded variants of the edited photos are included in the delivered image folder. The delivered manifest lists both original source SHA256 and delivered SHA256, plus branding edit status. watermark-change-log.json records the edited entries.

EDITABLE CATALOGUE
Open Catalogue.html with the images/ and assets/ folders beside it. build_catalogue.py and editorial.py rebuild the PDF and workbook with ReportLab, Pillow and openpyxl. The HTML is a responsive companion layout rather than the exact PDF layout.

REFERENCE DATA
Product-Reference.xlsx contains 11 product summaries, 352 source size/width variants, 83 image records and the source size chart. Source retail USD prices are historical observations, not FBG quotations. FBG prices remain Price on request. Stock and processing times describe the source listing when retrieved, not FBG commitments.

SOURCE AND EDITS
https://myleathergear.com/collections/leather-boots
Source photography and specifications: My Leather Gear. FBG marks on the 12 affected photos were added digitally at the user's request; they do not verify physical boot branding or manufacturer identity. Image edits use AI and should be checked against actual goods when confirming orders. The cover is AI-generated campaign artwork inspired by the supplied FBG reference. FBG-LB codes are editorial references, not source/manufacturer SKUs. Original files remain preserved in the prior source archive, outside this delivery pack.

FIT
The source chart is reproduced as supplied and is not a universal size conversion. It repeats UK/AUS 7 for US 7.5 and 8; confirm measurements, width and calf fit before ordering.
